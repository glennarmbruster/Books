"""Validate the chapter files and refresh the bookshelf's offline edition."""
import argparse
from datetime import date
from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from xml.etree import ElementTree
from urllib.parse import urlsplit
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

book = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--check', action='store_true', help='check without writing')
parser.add_argument('--review', metavar='PAGE', help='record a completed human review of one reference page')
parser.add_argument('--date', type=date.fromisoformat, help='review date as YYYY-MM-DD (default: today)')
parser.add_argument('--note', help='short, shareable description of the review')
args = parser.parse_args()
if args.review:
    if args.check or not args.note or not args.note.strip():
        parser.error('--review requires --note and cannot be combined with --check')
    from review_history import record_review
    record_review(book, args.review, args.date or date.today(), args.note.strip())
    sys.exit(0)
if args.date or args.note:
    parser.error('--date and --note require --review')


def require(value, message):
    if not value:
        raise SystemExit(message)


def words(values):
    return isinstance(values, list) and values and all(isinstance(v, str) and v.strip() for v in values)


def check_sample_text(value, path):
    """Reject personal contact details or device paths accidentally pasted into book files."""
    for match in re.finditer(r'[A-Za-z0-9._%+-]+@([A-Za-z0-9.-]+\.[A-Za-z]{2,})', value):
        host = match[1].lower()
        require(host.endswith(('.test', '.invalid')) or host in {'example.org','example.net','example.com'}, f'Use a made-up email address in {path}')
    require(not re.search(r'(?:/Users/|C:\\Users\\|/home/)[A-Za-z0-9._-]+', value, re.I), f'Remove the personal home folder in {path}')
    require(not re.search(r'(?<![\w.-])(?:\+1[-. ]?)?\(\d{3}\)[-. ]*\d{3}[-. ]\d{4}\b', value), f'Remove the personal phone number in {path}')


def check_sources(sources, key):
    require(sources, f'Missing sources in {key}')
    for label, link in sources:
        url = urlsplit(link)
        require(label and url.scheme == 'https' and url.hostname, f'Invalid source in {key}')


legacy = ['Starter'] * 3 + ['Intermediate'] * 4 + ['Advanced'] * 3 + ['Expert'] * 5
second = ['Starter'] * 6 + ['Intermediate'] * 7 + ['Advanced', 'Expert']
track_levels = {name: legacy + second for name in
                ('antigravity','ai-studio','claude-code','codex','copilot','devin')}
for name in ('claude-code', 'codex'):
    track_levels[name][13] = 'Advanced'
track_levels['gemini-app'] = second + second
track_levels['troubleshoot'] = ['Starter']*4 + ['Intermediate']*6 + ['Advanced']*4 + ['Expert']*2


short_track = ['Starter','Starter','Intermediate','Intermediate','Advanced','Expert']
track_levels['data-safety'] = short_track
track_levels['ship-app'] = short_track


def check_lab(lab, track, number):
    key = lab['id']
    require(key == f'lab-{track}-{number:02}', f'Unexpected lab order for {key}')
    require(words([lab[k] for k in ('level', 'requires', 'features', 'prompt')]), f'Incomplete brief in {key}')
    require(lab['level'] == track_levels[track][number-1], f'Unexpected level in {key}')
    require(words(lab['roles']) and len(lab['roles']) == 3, f'Check roles in {key}')
    require(len(lab['steps']) >= 3 and words(lab['check']), f'Incomplete walkthrough in {key}')
    for step in lab['steps']:
        require(words([step[k] for k in ('title', 'text', 'help')]), f'Step missing guidance in {key}')
        if 'code' in step:
            require(words([step['code']]), f'Empty example in {key}')
    check_sources(lab['sources'],key)


def refresh_kit(folder):
    # Fixed file order and metadata make identical kits produce identical editions.
    for name in ('mailboxes.csv', 'Test-Inventory.ps1', 'Reference/Get-MailboxInventory.ps1', 'README.md'):
        require((folder / name).is_file(), f'Missing practice file {name}')
    packed = io.BytesIO()
    with ZipFile(packed, 'w') as archive:
        for source in sorted(folder.rglob('*')):
            if source.is_file() and not any(p.startswith('.') for p in source.relative_to(folder).parts):
                info = ZipInfo((Path(folder.name) / source.relative_to(folder)).as_posix())
                info.compress_type = ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, source.read_bytes())
    output = folder.with_suffix('.zip')
    if not output.exists() or packed.getvalue() != output.read_bytes():
        require(not args.check, f'Run update_edition.py to refresh {output.name}')
        output.write_bytes(packed.getvalue())
    return output.relative_to(book).as_posix()


manifest = json.loads((book / 'edition.json').read_text())
edition_date = date.fromisoformat(manifest['reviewed'])
groups = manifest['groups']
ids = set()
assets = ['index.html', 'reader.css', 'reader.js', 'guides.js', 'guide.css', 'content/figures.json', 'content/worked.json', 'content/models.json', 'edition.json', '../book-pager.js', '../shelf-art/all-about-ai.jpg']
kit = refresh_kit(book / 'practice' / 'exchange-inventory')
assets.append(kit)
assets.append('practice/exchange-inventory/case-guide.json')
case_rows = json.loads((book / assets[-1]).read_text())
case_names = {p.name for p in (book/'practice/exchange-inventory/cases').iterdir() if p.is_file() and not p.name.startswith('.')}
require({r['file'] for r in case_rows} == case_names and len(case_rows) == len(case_names), 'Map every practice file once')
require(len({r['prefix'] for r in case_rows}) == len(case_rows), 'Each practice file needs a distinct label prefix')
for row in case_rows:
    require(re.fullmatch(r'[A-Z]{2,4}',row['prefix']) and re.search(r'\b'+row['prefix']+r'\d+\b',(book/'practice/exchange-inventory/cases'/row['file']).read_text()), 'Check label prefix in '+row['file'])
    check_sources(row['sources'],row['file'])
lab_count = 0
guide_ids = set()
reference_ids = set()
build_labs = []
writing_labs = []
build_spec = None
require(groups, 'List at least one group in edition.json.')
for group in groups:
    require(group['title'] and date.fromisoformat(group['reviewed']) <= edition_date, 'Check group title and review date.')
    require(re.fullmatch(r'[a-z0-9-]+\.json', group['file']), 'Use a plain JSON filename for each group.')
    path = 'content/' + group['file']
    require(path not in assets, f'Duplicate group file {path}')
    assets.append(path)
    chapters = json.loads((book / path).read_text())
    require(chapters, f'Empty group {path}')
    if group.get('track'):
        require(words([group['startLabel'],group['gettingStarted']]) and (urlsplit(group['startUrl']).scheme == 'https' or group['startUrl'] in {'#get-kit','#first-project','#which-account'}), f'Check setup help in {path}')
        require(group['track'] in track_levels and len(chapters) == len(track_levels[group['track']]), f'Incorrect track or lab count in {path}')
    for number, ch in enumerate(chapters, start=1):
        key = ch['id']
        require(re.fullmatch(r'[a-z0-9-]+', key) and key not in ('contents', 'labs', 'start') and key not in ids, f'Invalid or duplicate ID {key}')
        ids.add(key)
        require(words([ch['title'], ch['summary']]), f'Incomplete page {key}')
        if group.get('guide'):
            require(words(ch['where']) and words(ch['roles']) and len(ch['roles']) == 3, f'Check setup and roles in {key}')
            require(len(ch['actions']) >= 4 and ch['topic'], f'Incomplete guide {key}')
            for step in ch['actions']:
                require(words([step[k] for k in ('title','do','see','stuck')]), f'Missing walkthrough in {key}')
            check_sources(ch['sources'],key)
            guide_ids.add(key)
            continue
        if group.get('track'):
            check_lab(ch, group['track'], number)
            if 'writeYourOwn' in ch:
                exercise = ch['writeYourOwn']
                require(ch['level'] in {'Intermediate','Advanced'} and
                        words([exercise[k] for k in ('goal','given','compare')]), f'Check prompt-writing exercise in {key}')
                writing_labs.append(group['track'])
            if ch.get('comparison'):
                require(ch['comparison'] == 'build-off', f'Unknown comparison in {key}')
                build_labs.append(ch)
            require('kit' not in ch or ch['kit'] == kit, f'Unknown kit in {key}')
            for case in ch.get('caseFiles', []):
                require(re.fullmatch(r'[a-z0-9-]+\.(?:txt|csv|json|ps1|md|eml)', case, re.I), f'Invalid case file in {key}')
                case_path = 'practice/exchange-inventory/cases/' + case
                require((book / case_path).is_file(), f'Missing {case_path}')
                if case_path not in assets: assets.append(case_path)
            if 'sampleApp' in ch:
                sample = ch['sampleApp']
                require(re.fullmatch(r'practice/browser/[a-z0-9-]+\.html',sample) and (book/sample).is_file(), f'Unknown app in {key}')
                if sample not in assets: assets.append(sample)
            lab_count += 1
            continue
        reference_ids.add(key)
        require(words(ch['tags']) and len(set(ch['tags'])) == len(ch['tags']) and
                all(re.fullmatch(r'[a-z0-9-]+', tag) for tag in ch['tags']), f'Invalid reference tags in {key}')
        require(date.fromisoformat(ch['lastVerified']) <= date.fromisoformat(group['reviewed']) and
                ch['verificationBasis'] in {'previous group review','page review'}, f'Invalid page review in {key}')
        require('unverified' not in ch or words(ch['unverified']), f'Empty unverified details in {key}')
        if key == 'build-off':
            build_spec = ch['buildSpec']
            require(words([build_spec['prompt'], build_spec['followUp']]) and
                    words(build_spec['check']) and len(set(build_spec['check'])) == len(build_spec['check']) == 5,
                    'The build-off needs one prompt, five different checks and one follow-up')
            require([part['buildPart'] for part in ch['sections'] if 'buildPart' in part] ==
                    ['prompt','scorecard','followUp'], 'Check build-off section order')
            scorecard = next(part['table'] for part in ch['sections'] if part.get('buildPart') == 'scorecard')
            require(scorecard['columns'] == ['Criteria','What to Look For','Points','Notes'] and
                    len(scorecard['rows']) == 4, 'Check the four-column build-off scorecard')
        require(ch['sections'], f'Incomplete chapter {key}')
        intro = ch['intro']
        require(words([intro[k] for k in ('what', 'features', 'exchange', 'm365', 'developer')]) and intro['sources'], f'Incomplete introduction in {key}')
        for label, link in intro['sources']:
            require(label and urlsplit(link).scheme == 'https' and urlsplit(link).hostname, f'Invalid introduction source in {key}')
        for section in ch['sections']:
            require(section['title'] and words(section['paragraphs']) and section['sources'], f'Incomplete section in {key}')
            if 'practicePage' in section:
                sample = section['practicePage']
                require(re.fullmatch(r'practice/browser/[a-z0-9-]+\.html',sample) and (book/sample).is_file(), 'Missing linked practice page in '+key)
                if sample not in assets: assets.append(sample)
            for label, link in section['sources']:
                url = urlsplit(link)
                require(label and url.scheme == 'https' and url.hostname, f'Invalid source in {key}')
            if 'exercise' in section:
                exercise = section['exercise']
                require(words([exercise['prompt']]) and words(exercise['answer']), f'Incomplete exercise in {key}')
                for question in exercise.get('questions', []):
                    choices = question['choices']
                    require(words([question['prompt'], question['why']]) and words(choices) and
                            len(set(choices)) == len(choices) >= 2 and type(question['correct']) is int and
                            0 <= question['correct'] < len(choices), f'Invalid practice choice in {key}')
            if 'trialTools' in section:
                require(key == 'troubleshoot-trial' and section['trialTools'] == ['Claude','ChatGPT','Gemini','Microsoft 365 Copilot Chat'], 'Check blank diagnostic trial rows')
            if 'table' in section:
                tbl = section['table']
                require(words(tbl['columns']) and tbl['rows'], f'Empty table in {key}')
                require(all(words(row) and len(row) == len(tbl['columns']) for row in tbl['rows']), f'Invalid table in {key}')

desk = next(ch for ch in json.loads((book/'content/reference-desk.json').read_text()) if ch['id']=='reference-changes')
expected_surfaces = {'chat','artifacts','projects','code','connectors','browser','scheduled','voice','files'}
for vendor, alternate in [('claude',set()),('gemini',{'notebook','canvas'})]:
    pages = json.loads((book/'content'/f'{vendor}-reference.json').read_text())
    expected = (expected_surfaces - {'projects','artifacts'} | alternate) if alternate else expected_surfaces
    expected = expected | ({'memory','skills','style','research','thinking'} if vendor=='claude' else {'gems','research','personal','workspace','creation'})
    for page in pages:
        require([s['title'] for s in page['sections']] == ['What it is for','Do this first','What it cannot do','Plan and availability','Gotchas','Official docs'], 'Missing surface guide section in '+page['id'])
        links = {u for part in page['sections'] for _,u in part['sources']}
        require(len(links)>=2 and page['summary']!=page['intro']['what'], 'Check sources or introduction in '+page['id'])
    require(len(pages) == len(expected) and {p['surface'] for p in pages} == expected and
            all(p['id'] == vendor+'-reference-'+p['surface'] and p['id'] in reference_ids for p in pages),
            'Missing full-potential surface for '+vendor)
require({'reference-tags','reference-job-picker','reference-prompts','reference-changes'} <= reference_ids, 'Missing reference desk page')
history = next(s['entries'] for s in desk['sections'] if 'entries' in s)
require(history and all(date.fromisoformat(row['date']) <= edition_date and row['where'] in ids and
        words([row['what']]) and row['kind'] in {'edition','review','source check'} for row in history), 'Invalid change history')
tracks = [group['track'] for group in groups if group.get('track')]
require(len(tracks) == len(track_levels) and set(tracks) == set(track_levels) and
        lab_count == sum(map(len, track_levels.values())), 'Unexpected lab tracks or total')
require(len(writing_labs) == 20 and set(writing_labs) == set(track_levels) - {'data-safety','troubleshoot','ship-app'},
        'Expected 20 optional prompt exercises across the original tracks')
comparison_ids = {'lab-gemini-app-14','lab-claude-code-14','lab-codex-14'}
require(manifest.get('version') == 7 and build_spec is not None, 'Expected edition 7 with the four-tool build-off')
require({lab['id'] for lab in build_labs} == comparison_ids, 'Expected three shared Lab 14 builds')
for lab in build_labs:
    require(lab['prompt'] == build_spec['prompt'] and lab['check'] == build_spec['check'],
            'The shared prompt and all five checks must match word for word in ' + lab['id'])
catalog = json.loads((book / 'content/models.json').read_text())
require(date.fromisoformat(catalog['reviewed']) <= edition_date, 'Check model catalog date')
values = catalog['values']
require(values, 'Empty model catalog')
for field, entry in values.items():
    require(re.fullmatch(r'[a-z0-9.-]+',field) and words([entry['text']]), f'Invalid model field {field}')
    check_sources([[field,entry['source']]],field)
used = set()
def check_refs(value):
    if isinstance(value, str):
        def take(match):
            field = match[1]
            require(field in values, f'Unknown model field {field}')
            used.add(field)
            return values[field]['text']
        clean = re.sub(r'\{\{model\.([a-z0-9.-]+)\}\}',take,value)
        require('{{model.' not in clean, 'Unresolved model field')
    elif isinstance(value, list):
        for item in value: check_refs(item)
    elif isinstance(value, dict):
        for item in value.values(): check_refs(item)
def strings_in_content(value):
    if isinstance(value, str):
        if not value.startswith('https://'): yield value
    elif isinstance(value, list):
        for item in value: yield from strings_in_content(item)
    elif isinstance(value, dict):
        for key,item in value.items():
            if key not in {'id','sources'}: yield from strings_in_content(item)

model_groups = {'gemini.json','claude.json','chatgpt.json','other-tools.json','field-comparisons.json'}
fixed_fields = {entry['text'] for key,entry in values.items()
                if key.endswith('.id') or (key.endswith('.name') and re.search(r'\d',entry['text']))}
for group in groups:
    rows = json.loads((book/'content'/group['file']).read_text())
    for item in rows:
        for section in item.get('sections', []):
            for prompt in section.get('prompts', []):
                require(words([prompt['tool'],prompt['title'],prompt['text']]) and prompt['page'] in reference_ids, 'Invalid prompt library reference')
        if 'relatedLabs' in item:
            links = item['relatedLabs']
            require(words(links) and len(links) == len(set(links)) and all(link in ids and link.startswith('lab-') for link in links), 'Unknown or repeated lab link in '+item['id'])
        require('firstGuide' not in item or item['firstGuide'] in guide_ids, 'Invalid first lesson for '+item['id'])
    if group['file'] in model_groups:
        for line in strings_in_content(rows):
            without_refs = re.sub(r'\{\{model\.[a-z0-9.-]+\}\}', '', line)
            require(not any(term.lower() in without_refs.lower() for term in fixed_fields), 'Move the model name or API ID into the catalog in '+group['file'])
            require(not re.search(r'\$\d+(?:\.\d+)?\s+(?:in|out)\b|(?:limit(?: is| of)?|up to|maximum|window of)\s+[0-9][0-9,]*\s+(?:million\s+)?(?:input |output )?tokens\b',without_refs,re.I), 'Use a catalog field for model limits or token rates in '+group['file'])
    check_refs(rows)
examples = json.loads((book / 'content/worked.json').read_text())
require(len(examples) == len(ids - guide_ids) and {ex['id'] for ex in examples} == ids - guide_ids, 'Every reference and lab needs its own worked example')
for ex in examples:
    require(words([ex[k] for k in ('premise','before','try','after','why','rescue')]), 'Incomplete worked example '+ex['id'])
    key = ex['id']
    require(len(ex['before']) >= 100 and re.search(r'[?]|\b(?:list|read|return|count|give|match|paste|report)\b',ex['before'],re.I), 'Worked card needs data and an instruction in '+key)
    steps = ex['try'].splitlines()
    require(2 <= len(steps) <= 5 and all(line.startswith(f'{n}. ') and len(line)>12 for n,line in enumerate(steps,1)), 'Number the worked steps in '+key)
    require(re.fullmatch(r'First run: .+?\. Second run: .+?\. .+',ex['after']) and len(ex['after']) >= 40, 'Show the checked result of both runs in '+key)
    require(len(ex['why']) >= 20 and len(ex['rescue']) >= 35 and re.search(r'\b(?:send|ask|type|write|retry|repeat)\b',ex['rescue'],re.I), 'Give the reader a rescue message in '+key)
check_refs(examples)
figures = json.loads((book / 'content/figures.json').read_text())
check_refs(figures)
require(used == set(values), 'Unused model fields: ' + ', '.join(sorted(set(values)-used)))
previous_diagrams = """
    tokens-context chat-project-agent vibe-coding-loop model-picker structured-json tool-calling
    offline-pwa cost-per-win diff-review notebook-grounding deep-research m365-grounding
    exchange-pipeline git-branch-pr pagination-loop zero-vs-blank
""".split()
new_diagrams = """
    devin-speed-modes blueprint-snapshot session-side-chat devin-review-flow skill-reuse
    ticket-to-session access-four-scopes outposts-network fleet-pilot acu-metrics
    gemini-surfaces notebook-studio ai-studio-pipeline multimodal-io mindmap-connections quiz-from-notes
    claude-surfaces plan-then-edit connector-vs-browser svg-vs-raster effort-dial search-vs-analysis
    local-vs-cloud-codex media-handoff thread-to-decision denominator-trap copilot-surface-choice
    claim-to-source browser-permissions local-offline-ai blind-model-trial game-state-loop
    undo-history-stack fifo-queue atomic-file-swap csv-quote-shield four-way-buildoff
    case-loop mail-checkpoint device-evidence hybrid-route-proof mail-auth-evidence sharing-gate pasted-instructions ship-release ship-secret
""".split()
new_svg_files = {f'diagram-{name}.svg' for name in new_diagrams}
diagrams = new_svg_files | {f'diagram-{name}.svg' for name in previous_diagrams}
require(len(figures) == len(diagrams) + 41 and {f['file'] for f in figures if f['file'].endswith('.svg')} == diagrams,
        'Expected all named diagrams and 41 other pictures')
illustrated = {page for figure in figures for page in [figure['lesson'], *figure.get('also', [])]}
milestones = {f'lab-{track}-{n:02}' for track, levels in track_levels.items()
              for n in {1, 15, len(levels) - 1, len(levels)} if n <= len(levels)}
required_pages = reference_ids | milestones | {'lab-gemini-app-10','lab-gemini-app-24','lab-gemini-app-27'}
require(required_pages <= illustrated, 'Missing figures on ' + ', '.join(sorted(required_pages - illustrated)))
require({p.name for p in (book/'pictures').glob('*') if p.is_file() and not p.name.startswith('.')} == {f['file'] for f in figures}, 'Picture list does not match files on disk')
for fig in figures:
    name = fig['file']
    require(re.fullmatch(r'[a-z0-9-]+\.(webp|svg)', name), f'Invalid picture name {name}')
    path = 'pictures/' + name
    require(fig['lesson'] in ids and path not in assets and words([fig['credit'], fig['caption'], fig['alt']]), f'Check picture {name}')
    related = fig.get('also', [])
    require(set(related) <= ids and len(set([fig['lesson'],*related])) == len(related) + 1, f'Unknown or duplicate figure target in {name}')
    if name == 'diagram-four-way-buildoff.svg':
        require(fig['lesson'] == 'build-off' and comparison_ids <= set(related), 'Link the build-off diagram to the chapter and all three labs')
    if fig['source'].startswith('#'):
        require(fig['source'][1:] in ids, f'Unknown local figure source {name}')
    else:
        check_sources([[fig['credit'], fig['source']]],name)
    if name in diagrams:
        svg = ElementTree.parse(book / path).getroot()
        ns = '{http://www.w3.org/2000/svg}'
        if name in new_svg_files:
            colors = {el.get(attr) for el in svg.iter() for attr in ('fill', 'stroke')
                      if el.get(attr) not in (None, 'none')}
            require(colors == {'#faf6ea', '#182c2d', '#145756', '#8b571b'}, f'Check the book palette in {name}')
        require(svg.tag == ns+'svg' and svg.get('viewBox') and svg.findtext(ns+'title') and svg.findtext(ns+'desc'), f'Diagram needs a title and description: {name}')
        require(all(el.tag in {ns+t for t in ('svg','title','desc','defs','marker','rect','text','path')} for el in svg.iter()), f'Unexpected SVG element {name}')
    else:
        require((book / path).read_bytes()[8:12] == b'WEBP', f'Invalid WebP {name}')
    assets.append(path)

for path in [*assets, 'UPDATING.md', *[p.relative_to(book).as_posix() for p in (book/'practice/exchange-inventory').rglob('*') if p.is_file()]]:
    if Path(path).suffix in {'.json','.svg','.csv','.md','.ps1','.html','.js','.css','.txt','.eml'}:
        check_sample_text((book/path).read_text(), path)

digest = sha256()
for path in [*assets, '../table-books-worker.js']:
    digest.update(path.encode() + b'\0' + sha256((book / path).read_bytes()).digest())
edition = 'all-about-ai-' + digest.hexdigest()[:16]
worker = ("// Generated by update_edition.py\nconst edition = " + json.dumps(edition) + ";\nconst files = "
          + json.dumps(assets, indent=2) + ";\nimportScripts('../table-books-worker.js');\n")
shelf_path = book.parent / 'index.html'
shelf, count = re.subn(r'(data-book="all-about-ai" data-edition=")[^"]+(")', rf'\g<1>{edition}\2', shelf_path.read_text())
require(count == 1, 'Expected exactly one All About AI card in the bookshelf.')
for path, expected in [(book / 'sw.js', worker), (shelf_path, shelf)]:
    if not path.exists() or path.read_text() != expected:
        require(not args.check, f'Run update_edition.py to refresh {path.name}')
        path.write_text(expected)
print(f'{len(ids)-lab_count-len(guide_ids)} reference chapters, {lab_count} labs, {len(guide_ids)} beginner lessons, {len(figures)} pictures. {edition}')

subprocess.run([sys.executable, str(book / 'export_book.py'), *(['--check'] if args.check else [])], check=True)
